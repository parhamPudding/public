<?php

/**
 * Class Runners
 */
class Runners extends ApiController
{
    /**
     * API: api/runners/get/page/per-page
     * or api/runners/get
     *
     * @method get
     *
     * @param int $page
     * @param int $perPage
     * @generate $json
     */
    public function get($page = null, $perPage = PER_PAGE)
    {
        $json = HttpClient::request(base_url(FILE_PATH), $page, $perPage);
        $count = HttpClient::$count;
        Data::debug('total count: '.$count);
        Data::set('pages', round($count/PER_PAGE));
        Data::set('runners', $json);
        $this->done();
    }
}

