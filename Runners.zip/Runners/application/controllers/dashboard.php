<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Class Dashboard
 */
class Dashboard extends ViewController
{
    /**
     * Dashboard constructor.
     */
    public function __construct()
    {
        parent::__construct();

    }

    public function index()
    {
	    $this->get();
	}

    /**
     * @method get
     *
     * @param int $page
     * @param int $perPage
     */
    public function get($page = 1, $perPage = PER_PAGE)
    {
        $json = HttpClient::request(base_url(FILE_PATH), $page, $perPage);
        $count = HttpClient::$count;
        Data::set('runners', $json);
        Data::set('pages', round($count/PER_PAGE));
        //This is for debugging and development environment,
        // you can check the data in the source page.
        Data::debug('total count: '.$count);
        View::setTitle('Runners');
        $this->view('dashboard');
    }
}
