<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Class ApiController
 */
class ApiController extends BaseController
{
    /**
     * @var mixed $bench_start
     */
    private $bench_start;

    /**
     * ApiController constructor.
     */
    public function __construct()
    {
        parent::__construct();
        $this->bench_start = microtime(true);
    }

    /**
     * @method done
     * @generate json
     */
    public function done()
    {
        header('Content-Type: application/json');
        Data::set('status', 'OK');
        $bench = microtime(true) - $this->bench_start;
        Data::set('bench', round($bench * 1000, 2).'ms');
        $json = json_encode(Data::getData());
        if ($json === false) {
            echo json_encode([
                'status' => 'error',
                'description' => json_last_error_msg()
            ]);
        } else if (empty($json)) {
            print_s(Data::getData());
        } else {
            echo $json;
        }

        exit;
    }

    /**
     *
     * generate error message
     *
     * @method fail
     * @param string $msg
     */
    public function fail($msg = '')
    {
        header('Content-Type: application/json');
        Data::set('error', $msg);
        $json = json_encode(Data::getData());
        if ($json === false) {
            echo json_encode(['status' => 'error', 'description' => 'json encode error']);
        } else if (empty($json)) {
            print_s(Data::getData());
        } else {
            echo $json;
        }

        exit;
    }
}
