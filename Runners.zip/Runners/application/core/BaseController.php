<?php

require FCPATH.'/application/libraries/Helpers/guzzle/vendor/autoload.php';

const FILE_PATH = '/files/runners.json';
const PER_PAGE  = 100;

/**
 * Class BaseController
 */
class BaseController extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        /**
         * Initialize HttpClient
         */
        HttpClient::init();
    }
}
