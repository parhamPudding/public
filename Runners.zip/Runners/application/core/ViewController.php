<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Class ViewController
 */
class ViewController extends BaseController
{
    function __construct()
    {
        parent::__construct();
    }

    /**
     * Generate view, and data
     *
     * @method view
     *
     * @param $view
     */
    protected function view($view)
    {
        View::setBody(get_instance()->load->view($view, Data::getData(), true));
        View::setHeader(get_instance()->load->view('template/header.php', Data::getData(), true));
        View::setFooter(get_instance()->load->view('template/footer.php', Data::getData(), true));
        get_instance()->load->view('template/wrapper.php');
    }
}
