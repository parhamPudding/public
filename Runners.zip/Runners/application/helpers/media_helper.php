<?php

/**
 * @system_media_path
 * @system file name : those files is used by system.
 *
 * Create a local URL based on your file type.
 * Parameter can be passed in as a string, e.g. favicon.jpg.
 *
 * @access	public
 * @param string
 * @return	string
 */
if(!function_exists('1system_media_path')){
    function system_media_path($name)
    {
        return base_url('/assets/media/images/'.$name);
    }
}

