<?php
/**
 * print_s
 */
if(! function_exists("print_s")){
    function print_s($var,$bool=false)
    {
        $result = '<pre>';
        $result .= print_r($var,true);
        $result .= '</pre>';
        if($bool) {
            return $result;
        } else{
            echo $result;
        }

        return true;
    }
}

/**
 * print and die
 */
if(! function_exists("print_d")){
    function print_d($var)
    {
        print_s($var);
        die;
    }
}

