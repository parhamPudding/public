<?php
$lang['dashboard_title'] = 'Runners';
