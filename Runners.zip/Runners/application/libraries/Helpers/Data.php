<?php

class Data
{
    /**
     * @var static $instance
     */
    protected static $instance = null;

    /**
     * @var array data
     */
    var $data = [
        'bench' => null,
        'debug' => []
    ];

    /**
     * @return Data
     */
    protected static function getInstance()
    {
        if (!isset(static::$instance)) {
            static::$instance = new Data();
        }

        return static::$instance;
    }

    /**
     * set data by keyName and send to view
     *
     * @method set
     *
     * @param $key
     * @param $value
     */
    public static function set($key, $value)
    {
        static::getInstance()->data[$key] = $value;
    }

    /**
     * Detailed debug information.
     *
     * @param $info
     */
    public static function debug($info)
    {
        $time = explode(" ",microtime());
        $time = date("H:i:s", $time[1]).substr((string)$time[0],1,4);
        if (is_object($info)) {
            $info = array($time => $info);
        } else if (is_array($info)) {
            $info = array($time => $info);
        } else {
            $info = "$time: $info";
        }

        static::getInstance()->data['debug'][] = $info;
    }

    /**
     *
     * @method getData
     *
     * @return array
     */
    public static function getData()
    {
        return static::getInstance()->data;
    }
}

