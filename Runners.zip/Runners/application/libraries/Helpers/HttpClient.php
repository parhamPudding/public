<?php

/**
 * Class HttpClient
 */
class HttpClient
{
    /**
     * @var static $client
     * @var static $count
     */
    public static $client;
    public static $count;

    /**
     * Initialization HttpClient
     *
     * @method init
     */
    public static function init()
    {
        HttpClient::$client = new GuzzleHttp\Client();
    }

    /**
     *
     * @method request
     *
     * @param $path
     * @param null $page
     * @param int $perPage
     * @return array|mixed
     */
    public static function request($path, $page = null, $perPage = PER_PAGE)
    {
        try {
            $request = HttpClient::$client->request( 'GET', $path);
            $json =  json_decode($request->getBody(), true);
            HttpClient::$count = count($json);
            $offset = ($page - 1) * $perPage;
            $total  = $page * $perPage;
            $total  = ($total > count($json)) ? count($json) : $total;
            $years = [];
            $runners = [];
            foreach ($json as $row) {
                foreach ($row as $key => $val) {
                    if ($key == 'year' && !in_array($val, $years)) {
                        $years[] = $val;
                    }

                    if ($page && $key == 'id' && ( $val > $offset && $val <= $total )) {
                        $runners[] = $json[$val-1];
                    }

                }

            }

            Data::set('years', $years);
            if ($page) {
                return $runners;
            } else {
                return $json;
            }

        } catch (Exception $e) {
            // This is for debugging, you can see error messages in source page.
            $info = 'Caught exception: '. $e->getMessage()."\n";
            Data::debug($info);
        }

        return true;
    }
}

