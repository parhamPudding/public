<?php

/**
 * Class View
 */
class View
{
    /**
     * @var static $instance
     */
    protected static $instance = null;

    /**
     * @var string $title
     * @var string $data
     * @var string $header
     * @var string $body
     * @var string $footer
     */
    private $title = '';
    private $data;
    private $header;
    private $body;
    private $footer;

    /**
     * @return View
     */
    protected static function getInstance()
    {
        if (!isset(static::$instance)) {
            static::$instance = new View();
        }

        return static::$instance;
    }

    /**
     * @param mixed $key
     * @param mixed $value
     */
    public static function set($key, $value)
    {
        static::getInstance()->data[$key] = $value;
    }

    /**
     * @return array
     */
    public static function getData()
    {
        return static::getInstance()->data;
    }

    /**
     * @return mixed
     */
    public static function getHeader()
    {
        return static::getInstance()->header;
    }

    /**
     * @param mixed $header
     */
    public static function setHeader($header)
    {
        static::getInstance()->header = $header;
    }

    /**
     * @return mixed
     */
    public static function getBody()
    {
        return static::getInstance()->body;
    }

    /**
     * @param mixed $body
     */
    public static function setBody($body)
    {
        static::getInstance()->body = $body;
    }

    /**
     * @return mixed
     */
    public static function getFooter()
    {
        return static::getInstance()->footer;
    }

    /**
     * @param mixed $footer
     */
    public static function setFooter($footer)
    {
        static::getInstance()->footer = $footer;
    }

    /**
     * @param $title
     */
    public static function setTitle($title)
    {
        static::getInstance()->title = $title;
    }

    /**
     * @return string
     */
    public static function getTitle()
    {
        return static::getInstance()->title;
    }
}

