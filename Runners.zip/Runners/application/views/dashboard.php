<?php  // Filtering ?>
<div class="d-flex justify-content-center control">
    <div class="p-2 col-8 bg-gery-light rounded wrapper z-depth">
        <ul class="mt-3 list-unstyled">
            <li class="list-inline-item years">
                <?php  // handlebars ?>
            </li>
            <li class="list-inline-item">
                <button type="button" class="btn btn-danger reset">Reset</button>
            </li>
        </ul>
    </div>
</div>
<?php  // Content - body  ?>
<div class="mt-1 d-flex justify-content-center runners">
    <div class="p-2 col-8 bg-gery-light rounded wrapper z-depth">
        <div class="container rounded">
            <span class="sub-title selected-year"><h3>All runners</h3></span>
            <nav>
                <ul class="pagination pagination-sm">
                    <?php  // handlebars ?>
                </ul>
            </nav>
            <span class="data-wrapper bg-success">
                  <?php  // handlebars ?>
            </span>
        </div>
    </div>
</div>
