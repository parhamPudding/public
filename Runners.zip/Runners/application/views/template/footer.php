<?php // Footer ?>
<div class="d-flex justify-content-center">
    <div class="col-6 text-center font-italic">Runners project</div>
</div>
