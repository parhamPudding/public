let runners                 : any;
let pages                   : any;
let page                    : any = 1;
let years                   : any;
let subTitleElement         : any;
let dataWrapperElement      : any;
let paginationElement       : any;
let controlElement          : any;
let runnersTemplate         : any;
let paginationTemplate      : any;
let yearsDropDownTemplate   : any;
let subTitleTemplate        : any;

$(() =>{
    /**
     *
     * @type {{objects: (() => any)}}
     */
    let detect = {
        objects: function () {
            subTitleElement    = $('.runners .wrapper .sub-title.selected-year');
            dataWrapperElement = $('.runners .wrapper .data-wrapper');
            paginationElement  = $('.runners .wrapper .pagination');
            controlElement     = $('.control .wrapper');
        }
    };

    /**
     *
     * @type {{runners: ((pageID: any, callback: (runners: any) => void) => any)}}
     */
    let get = {
        runners:(pageID: any, callback:(runners: any)=> void)=> {
            $.getJSON('/api/runners/get/'+pageID, function(data) {
                console.log(data);
                callback(data);
            });
        }
    };

    /**
     *
     * @param page
     */
    let reloadData = function (page:any) {
        get.runners(page, (data: any)=>{
            pages = Array.apply(null, Array(data.pages)).map(function (x : number, i:number) { return i; });
            dataWrapperElement.html(runnersTemplate({item:data.runners}));
            paginationElement.html(paginationTemplate({item: pages}));
            subTitleElement.html(subTitleTemplate({}));
            controlElement.find('.years').html(yearsDropDownTemplate({item: data.years.sort()}));
            $("#item_"+ page).addClass('disabled');
        });
    };

    /**
     *
     * @param year
     */
    let reloadFilterData = function (year:any) {
        let runnersFilter            : any[] = [];
        let bestSecondsIDs           : any[] = [];
        let bestSecondsRunners       : any[] = [];
        let bestGroup                : any[] = [];
        get.runners(0, (data: any)=>{
            subTitleElement.html(subTitleTemplate({year: year}));
            dataWrapperElement.html('');
            paginationElement.html('');
            data.runners.sort(function (a:any,b:any) {
                if (a.secondLeg < b.secondLeg) {
                    return -1;
                }

                if (a.secondLeg > b.secondLeg) {
                    return 1;
                }

                return 0;
            });

            for (let i = 0; i < data.runners.length; i++) {
                if (year > 0) {
                    if (data.runners[i].year == year) {
                        runnersFilter.push(data.runners[i]);
                        bestSecondsRunners.push(data.runners[i]);
                        bestSecondsIDs.push(data.runners[i].id);
                    }

                } else {
                    runnersFilter.push(data.runners[i]);
                    bestSecondsRunners.push(data.runners[i]);
                    bestSecondsIDs.push(data.runners[i].id);
                }

            }

            bestSecondsIDs.splice(4);
            runnersFilter.sort(function (a:any,b:any) {
                if (a.firstLeg < b.firstLeg) {
                    return -1;
                }

                if (a.firstLeg > b.firstLeg) {
                    return 1;
                }

                return 0;
            });

            if (bestSecondsIDs.indexOf(runnersFilter[0].id) != -1) {
                let commonIndex = bestSecondsIDs.indexOf(runnersFilter[0].id);
                let index : number ;
                for (let i = 0; i < runnersFilter.length; i++) {
                    if (bestSecondsIDs.indexOf(runnersFilter[i].id) == -1) {
                        index = i;
                        break;
                    }

                }

                if ((runnersFilter[index].firstLeg - runnersFilter[0].firstLeg) >
                    (bestSecondsRunners[3].secondLeg - bestSecondsRunners[commonIndex].secondLeg)) {
                    bestGroup.push(bestSecondsRunners[commonIndex]);
                    for (let i = 0; i < bestSecondsRunners.length; i++) {
                        if ((bestSecondsRunners[i].id != bestSecondsRunners[commonIndex].id) && bestGroup.length < 4) {
                            bestGroup.push(bestSecondsRunners[i]);
                        }

                    }

                } else {
                    bestSecondsIDs.splice(3);
                    for (let i = 0; i < runnersFilter.length; i++) {
                        if (bestSecondsIDs.indexOf(runnersFilter[i].id) == -1) {
                            bestGroup.push(runnersFilter[i]);
                            break;
                        }

                    }

                    for (let i = 0; i < 3; i++) {
                        bestGroup.push(bestSecondsRunners[i]);
                    }

                }

            } else {
                bestSecondsRunners.splice(3);
                bestGroup.push(runnersFilter[0]);
                for (let i = 0; i < bestSecondsRunners.length; i++) {
                    bestGroup.push(bestSecondsRunners[i]);
                }

            }

            dataWrapperElement.html(runnersTemplate({item: bestGroup}));
        });
    };

    detect.objects();
    Handlebars.partials   = Handlebars.templates;
    runnersTemplate       = Handlebars.templates['body'];
    paginationTemplate    = Handlebars.templates['pagination'];
    yearsDropDownTemplate = Handlebars.templates['years'];
    subTitleTemplate      = Handlebars.templates['sub-title'];
    reloadData(page);

    paginationElement.on('click','.page-item', (e: any)=>{
        let pageID = $(e.target).data('id');
        reloadData(pageID);
    });

    controlElement.on('click', '.btn.reset', function () {
        reloadData(1);
    });

    controlElement.on('change', 'select#year', function (e:any) {
        let selectedYear = $(e.target).val();
        if (selectedYear) {
            reloadFilterData($(e.target).val());
        } else {
            reloadData(1);
        }

    });
});